/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.sp.senac.d154.lojacalcados;

/**
 *
 * @author junin
 */
public class LojaCalcados {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
